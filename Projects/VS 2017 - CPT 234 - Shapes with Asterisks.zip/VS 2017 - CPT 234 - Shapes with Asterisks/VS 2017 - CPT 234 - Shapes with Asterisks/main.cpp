// Programmer:		Your Name
// Date:			Date
// Program Name:	The name of the program
// Chapter:			Chapter # - Chapter name
// Description:		2 complete English sentences describing what the program does,
//					algorithm used, etc.

#define _CRT_SECURE_NO_WARNINGS // Disable warnings (and errors) when using non-secure versions of printf, scanf, strcpy, etc.
#include <stdio.h> // Needed for working with printf and scanf

int main(void)
{
	// Constant and Variable Declarations



	// *** Your program goes here ***

	printf("-------------------------------------------------------	" "\n");
	printf("*********  |     ***     |      *      |      *     	" "\n");
	printf("*       *  |   *     *   |     ***     |     * *     	" "\n");
	printf("*       *  |  *       *  |    *****    |    *   *    	" "\n");
	printf("*       *  |  *       *  |      *      |   *     *     	" "\n");
	printf("*       *  |  *       *  |      *      |  *       *   	" "\n");
	printf("*       *  |  *       *  |      *      |   *     *    	" "\n");
	printf("*       *  |  *       *  |      *      |    *   *     	" "\n");
	printf("*       *  |   *     *   |      *      |     * *      	" "\n");
	printf("*********  |     ***     |      *      |      *  		" "\n");
	printf("-------------------------------------------------------	" "\n");
	printf("*          |     ***     |             |  *********  	" "\n");
	printf("*          |   *     *   |   *     *   |  *      	 	" "\n");
	printf("*          |  *       *  |   *     *   |  *       	 	" "\n");
	printf("*          |  *       *  |   *     *   |  *		   	 	" "\n");
	printf("*          |  *       *  |   *     *   |  *********	 	" "\n");
	printf("*          |  *       *  |   *     *   |  *			 	" "\n");
	printf("*          |  *       *  |   *     *   |  *			 	" "\n");
	printf("*          |   *     *   |     * *     |  *          	" "\n");
	printf("*********  |     ***     |      *      |  *********  	" "\n");
	printf("-------------------------------------------------------	" "\n");
	return 0;
} // end main()
