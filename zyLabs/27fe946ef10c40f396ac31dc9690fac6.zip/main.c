#include <stdio.h>

int main(void) {

   /* Type your code here. */
   
   printf("Hello world!" "\n");
   printf("How are you?" "\n");
   printf("   (I'm fine)." "\n");
   
   return 0;
}